document.body.prepend(document.createElement('hotkey-map'))
document.body.prepend(document.createElement('tool-pallete'))