document.getElementsByTagName('hotkey-map')[0].remove()
document.getElementsByTagName('tool-pallete')[0].remove()